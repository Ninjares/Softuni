﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    static class Exception_message
    {
        public const string RefuelNeeded = "{0} needs refueling";
    }
}
