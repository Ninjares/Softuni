﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger
{
    enum Level
    {
        Info = 1,
        Warning,
        Error,
        Critical,
        Fatal,
    }
}
