﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals
{
    class Animal
    {
        public string name;
        public string favoriteFood;

        protected Animal(string name, string food)
        {
            this.name = name;
            favoriteFood = food;
        }
        public virtual string ExplainSelf()
        {
            return $"I am {name} and my favourite food is {favoriteFood}";
        }
    }
}
