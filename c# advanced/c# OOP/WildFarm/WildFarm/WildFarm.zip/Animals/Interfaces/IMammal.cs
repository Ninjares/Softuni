﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    interface IMammal
    {
        string LivingRegion { get; set; }
    }
}
