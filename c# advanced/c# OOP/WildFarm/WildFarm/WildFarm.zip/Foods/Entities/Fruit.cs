﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    class Fruit:Food
    {
        public Fruit(int quantity) : base(quantity)
        {

        }
    }
}
