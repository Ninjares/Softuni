﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    class Meat:Food
    {
        public Meat(int quantity) : base(quantity)
        {

        }
    }
}
