﻿using System;
namespace Animals
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //string animal = Console.ReadLine();
            //while (animal != "Beast!")
            //{
            //    if (!(animal == "Cat" || animal == "Dog" || animal == "Frog" || animal == "Kittens" || animal == "Tomcat")) Console.WriteLine("Invalid input!");
            //    else
            //    {
            //        string[] animalProperties = Console.ReadLine().Split();
            //        if (animalProperties[0] == "" || animalProperties[1] == "" || animalProperties[2] == "" ||
            //            int.Parse(animalProperties[1]) < 0 ||
            //            (animalProperties[2] != "Male" && animalProperties[2] != "Female")) Console.WriteLine("Invalid input!");
            //        else
            //        {
            //            string name = animalProperties[0];
            //            int age = int.Parse(animalProperties[1]);
            //            string gender = animalProperties[2];
            //            switch (animal)
            //            {
            //                case "Cat":
            //                    {
            //                        var cat = new Cat(name, age, gender);
            //                        Console.WriteLine(animal);
            //                        Console.WriteLine(cat);
            //                        cat.ProduceSound();
            //                        break;
            //                    }
            //                case "Dog":
            //                    {
            //                        var dog = new Dog(name, age, gender);
            //                        Console.WriteLine(animal);
            //                        Console.WriteLine(dog);
            //                        dog.ProduceSound();
            //                        break;
            //                    }
            //                case "Frog":
            //                    {
            //                        var frog = new Frog(name, age, gender);
            //                        Console.WriteLine(animal);
            //                        Console.WriteLine(frog);
            //                        frog.ProduceSound();
            //                        break;
            //                    }
            //                case "Tomcat":
            //                    {
            //                        var tomcat = new Tomcat(name, age);
            //                        Console.WriteLine(animal);
            //                        Console.WriteLine(tomcat);
            //                        tomcat.ProduceSound();
            //                        break;
            //                    }
            //                case "Kittens":
            //                    {
            //                        var kitten = new Kitten(name, age);
            //                        Console.WriteLine(animal);
            //                        Console.WriteLine(kitten);
            //                        kitten.ProduceSound();
            //                        break;
            //                    }
            //            }
            //        }
            //    }
            //    animal = Console.ReadLine();
        
        }
    }
}
