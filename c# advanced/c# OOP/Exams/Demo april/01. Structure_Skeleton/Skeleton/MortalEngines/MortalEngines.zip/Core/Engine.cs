﻿using MortalEngines.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.Core
{/*
    class Engine : IEngine
    {
        private IMachinesManager machinesManager = new MachinesManager();
        public void Run()
        {
            while (true)
            {
                string[] commands = Console.ReadLine().Split();
                if (commands[0] == "Quit") break;
                switch (commands[0])
                {
                    case "HirePilot":
                        {
                            machinesManager.HirePilot(commands[1]);
                            break;
                        }
                    case "PilotReport":
                        {
                            machinesManager.PilotReport(commands[1]);
                            break;
                        }
                    case "ManufactureTank":
                        {
                            machinesManager.ManufactureTank(commands[1], double.Parse(commands[2]), double.Parse(commands[3]);
                            break;
                        }
                }
            }
        }
    }*/
}
