﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    class Smartphone:Browser, Phone
    {
        public void Call(string number)
        {
            bool real = true;
            foreach (char a in number)
                if (!char.IsDigit(a)) { real = false; break; }
            if (real) Console.WriteLine($"Calling... {number}");
            else Console.WriteLine("Invalid number!");
        }

        public void Browse(string website)
        {
            bool real = true;
            foreach(char a in website)
                if(char.IsDigit(a)) { real = false; break; }
            if (real) Console.WriteLine($"Browsing: {website}!");
            else Console.WriteLine("Invalid URL!");
        }
    }
}
