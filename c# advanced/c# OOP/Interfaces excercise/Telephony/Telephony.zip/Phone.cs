﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface Phone
    {
        void Call(string number);
    }
}
