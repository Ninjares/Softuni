﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    interface Browser
    {
        void Browse(string url);
    }
}
