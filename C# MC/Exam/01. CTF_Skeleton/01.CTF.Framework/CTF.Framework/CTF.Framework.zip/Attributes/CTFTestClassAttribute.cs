﻿namespace CTF.Framework.Attributes
{
    using System;

    // ReSharper disable once InconsistentNaming
    public class CTFTestClassAttribute : Attribute
    {
    }
}
